param([int]$Step = 0)

function Ensure-GitRepo {
    if (-not (Test-Path ".git")) {
        git init
        git branch -m main
        git remote add origin https://github.com/shruti18j/java17-springboot-example.git
    }
}

function Push-Feature($branch, $paths, $message, $tag) {
    git checkout -b $branch 2>$null
    foreach ($p in $paths) { git add $p }
    git commit -m $message
    git push -u origin $branch
    Write-Host ("Open PR: https://github.com/shruti18j/java17-springboot-example/compare/main...$branch")
    Write-Host ("After merge, tag with: git tag -a $tag -m `"$message`"; git push origin $tag")
}

Ensure-GitRepo

if ($Step -eq 0) {
    Write-Host "Choose upload step (1-5):"
    Write-Host "1 = CI/CD + Docs"
    Write-Host "2 = OrgApp microservice"
    Write-Host "3 = File Upload Service"
    Write-Host "4 = Orders Service (Kafka+PubSub)"
    Write-Host "5 = Final integration (Postman + Pages)"
    $Step = [int](Read-Host "Enter step")
}

switch ($Step) {
  1 {
    $paths = @(".github", "docs", "GCP_SETUP.md", "setup_gcp_env.ps1", "pom.xml", ".gitignore", "README.md")
    Push-Feature "feature/setup-ci" $paths "chore: bootstrap CI/CD, docs, parent POM" "v1.0.1-setup-ci"
  }
  2 {
    $paths = @("org-app")
    Push-Feature "feature/orgapp" $paths "feat: add OrgApp microservice with /health" "v1.0.2-orgapp"
  }
  3 {
    $paths = @("file-upload-service")
    Push-Feature "feature/fileupload" $paths "feat: add File Upload service (upload/files/download)" "v1.0.3-fileupload"
  }
  4 {
    $paths = @("orders-kafka-service")
    Push-Feature "feature/orders" $paths "feat: add Orders service with Kafka + PubSub profiles" "v1.0.4-orders"
  }
  5 {
    $paths = @("orgapp_postman_collection.json", ".github/workflows/pages.yml", "post_upload_checklist.md")
    Push-Feature "feature/final" $paths "docs: add Postman, Pages workflow, checklist" "v1.0.5-final"
  }
  default {
    Write-Host "Unknown step."
  }
}
